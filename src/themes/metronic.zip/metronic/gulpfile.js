'use strict';

var requireDir = require('require-dir');

requireDir('./theme/metronic/tools/gulp', {recurse: true});